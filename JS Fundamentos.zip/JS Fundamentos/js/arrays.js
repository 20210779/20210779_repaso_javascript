

const boton = document.getElementById("aceptar");
const boton1 = document.getElementById("aceptar1");

boton.addEventListener("click", function () {
    const num1 = document.getElementById("n1").value;
const num2 = document.getElementById("n2").value;
const num3 = document.getElementById("n3").value;
const num4 = document.getElementById("n4").value;
const num5 = document.getElementById("n5").value;

const valor1 = parseInt(num1);
const valor2 = parseInt(num2);
const valor3 = parseInt(num3);
const valor4 = parseInt(num4);
const valor5 = parseInt(num5);

  const numeros = [valor1, valor2, valor3, valor4, valor5];
  const suma = numeros.reduce((acumulador, numero) => acumulador + numero, 0);

  console.log(`El resultado es: ${suma}. Reduce() sumara los valores
  ${valor1}+${valor2}+${valor3}+${valor4}+${valor5} para que quede un unico valor igual a ${suma}`);
});


const numeros = [1, 2, 3, 4, 5];

const numerosPares = numeros.filter(numero => numero % 2 === 0);

console.log(numerosPares); // Devuelve [2, 4]

boton1.addEventListener("click", function () {
    const num1 = document.getElementById("nu1").value;
const num2 = document.getElementById("nu2").value;
const num3 = document.getElementById("nu3").value;
const num4 = document.getElementById("nu4").value;
const num5 = document.getElementById("nu5").value;

const valor1 = parseInt(num1);
const valor2 = parseInt(num2);
const valor3 = parseInt(num3);
const valor4 = parseInt(num4);
const valor5 = parseInt(num5);

  const numerosPares = [valor1, valor2, valor3, valor4, valor5];
  const par = numerosPares.filter(numero => numero %2 === 0);
  const cantidadPares = par.length;

  console.log(`El resultado es: ${par}. Filter() solo devuelve los valores pares
  Encontrados: ${cantidadPares}`);
});


const apiUrl = 'https://pokeapi.co/api/v2/';
let numero = prompt("Coloca un nombre o número del pókemon que buscas, todo en minuscula")


async function obtenerPokemon(id) {
  try {
    const response = await fetch(`${apiUrl}pokemon/${id}`);
    if (!response.ok) {
      throw new Error('No se pudo obtener los datos del Pokémon');
    }
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error al obtener los datos del Pokémon:', error);
  }
}

async function mostrarPokemonEnDOM(id) {
  const pokemon = await obtenerPokemon(id);
  if (pokemon) {
    const pokemonInfoDiv = document.getElementById('pokemon');
    pokemonInfoDiv.innerHTML = `
      <h2>${pokemon.name}</h2>
      <img src="${pokemon.sprites.front_default}" alt="${pokemon.name}">
      <p>Altura: ${pokemon.height}</p>
      <p>Peso: ${pokemon.weight}</p>
      <p>Tipos: ${pokemon.types.map(type => type.type.name).join(', ')}</p>
    `;
  }
}


mostrarPokemonEnDOM(numero);

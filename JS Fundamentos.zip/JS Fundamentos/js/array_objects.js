



// Array de mis personajes
const famosos = [
    { imagen:"/img/Dicarpio.png" ,nombre: "Leonardo DiCaprio", profesion: "Actor" },
    { imagen:"/img/Tony.png" ,nombre: "Tony Stark", profesion: "Multimillonario, Playboy, Filantropo" },
    { imagen:"/img/musk.jpg" ,nombre: "Elon Musk", profesion: "Empresario" }
  ];


  const cartasHTML = famosos.map(famoso => `
  <div class="col-sm-4">
  <div class="card">
  <img src="${famoso.imagen}" class="card-img-top" alt="...  height="16px">
    <div class="card-body">
      <h5 class="card-title">${famoso.nombre}</h5>
      <p class="card-text">${famoso.profesion}</p>
    </div>
  </div>
  </div>
`);


// Agregar cartas 
const contenedorCartas = document.getElementById("cartas");
contenedorCartas.innerHTML = cartasHTML.join('');
